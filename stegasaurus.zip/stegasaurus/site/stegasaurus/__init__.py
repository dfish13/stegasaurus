
from stegasaurus.settings import *

DEBUG = True
ALLOWED_HOSTS = ['resnus.duckdns.org', 'www.resnus.duckdns.org']
